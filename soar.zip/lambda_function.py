def handler(event, context):
    print("SOAR test event:", event)
    return {"ok": True}
